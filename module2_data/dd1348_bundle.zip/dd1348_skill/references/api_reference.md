# DD Form 1348-1A Field Guide

This document provides detailed instructions for each field on the DD Form 1348-1A.

## Table of Contents
1. [Header Row Fields (MILSTRIP Card)](#header-row-fields)
2. [Block 1-4: Price and Shipping](#blocks-1-4)
3. [Block 5-15: Shipping Details](#blocks-5-15)
4. [Block 16-23: Item and Receipt Info](#blocks-16-23)
5. [Block 24-27: Document Data](#blocks-24-27)

---

## Header Row Fields (MILSTRIP Card)

The top row contains the MILSTRIP data card format (positions 1-80).

### Document Identifier (Position 1-3)
- **Purpose**: Identifies the type of document
- **Format**: 3-character alpha code
- **Common Values**:
  - `A0A` - Requisition
  - `A5J` - Referral Order
  - `AT_` - Turn-in document
- **Required**: YES

### Routing Identifier Code (Position 4-6)
- **Purpose**: Identifies destination routing
- **Format**: 3-character alphanumeric
- **Example**: `S9C`
- **Required**: YES

### Media & Status Code (Position 7)
- **Purpose**: Indicates media type and status
- **Format**: 1 character
- **Common Values**: `A`, `B`, `C`
- **Required**: YES

### National Stock Number (Position 8-22)
- **Purpose**: Unique identifier for the item
- **Format**: 13 characters with dashes: `XXXX-XX-XXX-XXXX`
- **Structure**:
  - Federal Supply Class (4 digits)
  - Country Code (2 digits)
  - Item Identification Number (7 digits)
- **Example**: `8415-01-545-8556`
- **Required**: YES
- **Resources**: Use WebFLIS or FEDLOG to look up NSNs

### Unit of Issue (Position 23-24)
- **Purpose**: Specifies how item is counted/issued
- **Format**: 2-character code
- **Common Codes**:
  | Code | Meaning |
  |------|---------|
  | EA | Each |
  | BX | Box |
  | CS | Case |
  | DR | Drum |
  | PR | Pair |
  | SE | Set |
  | KT | Kit |
  | GL | Gallon |
  | LB | Pound |
  | FT | Foot |
- **Required**: YES

### Quantity (Position 25-29)
- **Purpose**: Number of units being requisitioned
- **Format**: 5 digits, zero-padded
- **Example**: `00050` for 50 units
- **Required**: YES

### Document Number / DTID (Position 30-43)
- **Purpose**: Unique transaction identifier
- **Format**: 14 characters
- **Structure**:
  - DoDAAC (6 chars) + Julian Date (4 chars) + Serial Number (4 chars)
- **Example**: `W81K2F6029001`
  - `W81K2F` = Property book DoDAAC
  - `6029` = Julian date (year digit + day of year)
  - `0001` = Serial number
- **Required**: YES

### Supplementary Address (Position 45-50)
- **Purpose**: Ship-to DoDAAC if different from requisitioner
- **Format**: 6-character DoDAAC
- **Required**: NO (only if different from document number DoDAAC)

### Signal Code (Position 51)
- **Purpose**: Indicates how shipment should be routed
- **Format**: 1 character
- **Common Values**:
  | Code | Meaning |
  |------|---------|
  | A | Ship to requisitioner |
  | B | Ship to supplementary address |
  | C | Ship via parcel post |
  | J | Ship to mark-for addressee |
- **Required**: YES

### Fund Code (Position 52-53)
- **Purpose**: Identifies funding source
- **Format**: 2-character alphanumeric
- **Example**: `A3`, `P1`, `XX`
- **Required**: YES

### Distribution Code (Position 54-56)
- **Purpose**: Identifies distribution requirements
- **Format**: 1-3 characters
- **Required**: NO

### Project Code (Position 57-59)
- **Purpose**: Links to specific project/program
- **Format**: 3 characters
- **Example**: `ARC` (Arctic operations)
- **Required**: NO

### Priority Designator (Position 60-61)
- **Purpose**: Urgency of requirement
- **Format**: 2 digits (01-15)
- **Values**:
  | Priority | Force/Activity Designator |
  |----------|---------------------------|
  | 01-03 | Combat essential |
  | 04-08 | Operational |
  | 09-15 | Routine |
- **Required**: YES

### Required Delivery Date (Position 62-64)
- **Purpose**: When item is needed
- **Format**: Julian date (DDD) or days from today
- **Example**: `032` = 32nd day of year, or 32 days out
- **Required**: NO

### Advice Code (Position 65-66)
- **Purpose**: Special handling instructions
- **Format**: 2-character code
- **Example**: `2B`, `2C`
- **Required**: NO

### Condition Code (Position 71)
- **Purpose**: Indicates item serviceability
- **Format**: 1 character
- **Values**:
  | Code | Meaning |
  |------|---------|
  | A | Serviceable - issuable without qualification |
  | B | Serviceable - issuable with qualification |
  | C | Serviceable - priority issue |
  | D | Serviceable - test/modification |
  | E | Unserviceable - limited restoration |
  | F | Unserviceable - reparable |
  | G | Unserviceable - incomplete |
  | H | Unserviceable - condemned |
- **Required**: YES

### Unit Price (Position 74-80)
- **Purpose**: Original acquisition value per unit
- **Format**: Dollars and cents (7 characters)
- **Example**: `0485.00`
- **Required**: YES

---

## Blocks 1-4: Price and Shipping

### Block 1: Total Price
- **Purpose**: Extended price (Quantity x Unit Price)
- **Format**: Dollars and cents
- **Example**: `24250.00` (50 x 485.00)

### Block 2: Ship From
- **Purpose**: Originating DoDAAC and location name
- **Format**: DoDAAC + Location description
- **Example**: `W81UBU Fort Richardson Supply`

### Block 3: Ship To
- **Purpose**: Destination DoDAAC and location
- **Format**: DoDAAC + Facility name
- **Example**: `SG4310 DLA Disposition Services Arifjan`

### Block 4: Mark For
- **Purpose**: Additional routing/attention information
- **Format**: Free text
- **Example**: `SUPPLY SECTION`, `HW/HM ONLY`
- **Note**: Mark for HW/HM (Hazardous Waste/Material) only when applicable

---

## Blocks 5-15: Shipping Details

### Block 5: Document Date
- **Purpose**: Date document was prepared
- **Format**: Date

### Block 6: NMFC (National Motor Freight Classification)
- **Purpose**: Freight classification code

### Block 7: Freight Rate
- **Purpose**: Applicable freight rate

### Block 8: Type Cargo
- **Purpose**: Cargo type designation

### Block 9: PS (Packing Specification)
- **Purpose**: Packing requirements

### Block 10: Quantity Received
- **Purpose**: Actual quantity received (filled by receiver)

### Block 11: UP (Unit of Pack)
- **Purpose**: Packaging unit

### Block 12: Unit Weight
- **Purpose**: Weight per unit in pounds

### Block 13: Unit Cube
- **Purpose**: Volume per unit in cubic feet

### Block 14: UFC (Unit Freight Class)
- **Purpose**: Unit freight classification

### Block 15: SL (Service Level)
- **Purpose**: Transportation service level

---

## Blocks 16-23: Item and Receipt Info

### Block 16: Freight Classification Nomenclature
- **Purpose**: Freight classification description

### Block 17: Item Nomenclature
- **Purpose**: Full item description
- **Format**: Standard nomenclature from catalog
- **Example**: `PARKA, EXTREME COLD WEATHER, GEN III`
- **Required**: YES

### Block 18: Type Container
- **Purpose**: Container type code

### Block 19: Number of Containers
- **Purpose**: Total containers in shipment

### Block 20: Total Weight
- **Purpose**: Total shipment weight in pounds
- **Example**: `210`

### Block 21: Total Cube
- **Purpose**: Total shipment volume in cubic feet
- **Example**: `40`

### Block 22: Received By
- **Purpose**: Name/signature of receiver
- **Filled By**: Receiving party

### Block 23: Date Received
- **Purpose**: Date of receipt
- **Filled By**: Receiving party

---

## Blocks 24-27: Document Data

### Block 24: Document Number & Suffix
- **Purpose**: Full document number with any suffix
- **Format**: 14 chars + suffix if applicable
- **Example**: `W81K2F6029001A`

### Block 25: National Stock Number & Additional Data
- **Purpose**: NSN with any additional codes
- **Format**: Full NSN
- **Example**: `8415-01-545-8556`

### Block 26: Consolidated Data
Contains compressed data from MILSTRIP card:
- RIC (4-6): Routing Identifier Code
- UI (23-24): Unit of Issue
- QTY (25-29): Quantity
- CON CODE (71): Condition Code
- DIST (55-56): Distribution Code
- UP (74-80): Unit Price

### Block 27: Additional Data
- **Purpose**: Point of contact and supplementary information
- **Content**:
  - Requisitioner name
  - Phone/DSN number
  - Email address
  - Special handling instructions
- **Example**:
  ```
  POC: MAJ David Chen
  Phone: DSN 317-555-4520
  Email: david.chen@mail.mil
  SPECIAL: PROTECT FROM FREEZING
  ```

---

## DEMIL Codes Reference

| Code | Category | Description |
|------|----------|-------------|
| A | Non-MLI | No DEMIL required |
| B | MLI | No DEMIL required per DoD instruction |
| C | MLI | Remove/destroy key features |
| D | DoD MLI | Total destruction required |
| E | DoD MLI | Demilitarization instructions on item |
| F | MLI | Classified item - special handling |
| G | MLI | Trade Security Controls apply |
| N | - | No DEMIL required (legacy) |

---

## Data Sources for Field Lookup

- **NSN Lookup**: WebFLIS (https://www.dla.mil/HQ/LogisticsOperations/Services/FIC/WebFLIS/)
- **Unit of Issue**: https://www.dla.mil/HQ/InformationOperations/DLMS/elibrary/manuals/
- **DEMIL Codes**: DoD Manual 4160.28
- **DoDAAC Lookup**: DAASINQ system
