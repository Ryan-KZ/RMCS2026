#!/usr/bin/env python3
"""
DD Form 1348-1A Filler Script

Fills DD Form 1348-1A PDF with requisition data from JSON or dictionary input.
The form is an XFA-based fillable PDF with generic field names (TextField2[n]).

Usage:
    python fill_dd1348.py input_data.json template.pdf output.pdf

Or import and use programmatically:
    from fill_dd1348 import fill_dd1348_form
    fill_dd1348_form(data_dict, "dd13481a.pdf", "filled_form.pdf")
"""

import json
import sys
from datetime import datetime
from typing import Dict, Optional

# Try pypdf first, fall back to PyPDF2
try:
    from pypdf import PdfReader, PdfWriter
except ImportError:
    from PyPDF2 import PdfReader, PdfWriter


# =============================================================================
# FIELD MAPPING: Logical Names -> PDF Field IDs
# =============================================================================
# The DD 1348-1A PDF uses generic TextField2[n] naming. This mapping connects
# logical field names to their PDF field IDs based on form layout analysis.
#
# NOTE: This mapping was created by analyzing the form structure. If the PDF
# template changes, these mappings may need to be updated.
# =============================================================================

FIELD_MAPPING = {
    # Header row - MILSTRIP card positions (top row of form)
    # These map to the individual character positions 1-80

    # Block 1: Total Price
    "total_price_dollars": "form1[0].p1[0].#subform[0].TextField2[0]",
    "total_price_cents": "form1[0].p1[0].#subform[0].TextField2[1]",

    # Block 2: Ship From
    "ship_from": "form1[0].p1[0].#subform[0].TextField2[2]",

    # Block 3: Ship To
    "ship_to": "form1[0].p1[0].#subform[0].TextField2[3]",

    # Block 4: Mark For
    "mark_for": "form1[0].p1[0].#subform[0].TextField2[4]",

    # Block 24: Document Number & Suffix
    "document_number": "form1[0].p1[0].#subform[5].TextField2[49]",

    # Block 25: National Stock Number
    "nsn": "form1[0].p1[0].#subform[5].TextField2[50]",

    # Block 26: Consolidated data (RIC, UI, QTY, etc)
    "consolidated_data": "form1[0].p1[0].#subform[5].TextField2[51]",

    # Block 5: Doc Date
    "doc_date": "form1[0].p1[0].#subform[10].DateField1[0]",

    # Block 17: Item Nomenclature
    "item_nomenclature": "form1[0].p1[0].#subform[0].TextField2[43]",

    # Block 20: Total Weight
    "total_weight": "form1[0].p1[0].#subform[10].TextField2[63]",

    # Block 21: Total Cube
    "total_cube": "form1[0].p1[0].#subform[10].TextField2[64]",

    # Block 22: Received By
    "received_by": "form1[0].p1[0].#subform[10].TextField2[65]",

    # Block 23: Date Received
    "date_received": "form1[0].p1[0].#subform[10].DateField2[0]",

    # Block 27: Additional Data (POC info)
    "additional_data": "form1[0].p1[0].#subform[11].TextField2[73]",

    # MILSTRIP header row fields (positions on top line)
    # Unit of Issue (position 23-24)
    "unit_of_issue": "form1[0].p1[0].#subform[0].TextField2[5]",

    # Quantity (position 25-29)
    "quantity": "form1[0].p1[0].#subform[0].TextField2[6]",

    # Unit Price dollars
    "unit_price_dollars": "form1[0].p1[0].#subform[0].TextField2[20]",
    "unit_price_cents": "form1[0].p1[0].#subform[0].TextField2[21]",

    # Condition Code
    "condition_code": "form1[0].p1[0].#subform[0].TextField2[18]",

    # DEMIL Code
    "demil_code": "form1[0].p1[0].#subform[0].TextField2[14]",

    # Supply Condition Code
    "supply_condition_code": "form1[0].p1[0].#subform[0].TextField2[16]",
}


def format_price(price: float) -> tuple:
    """Split price into dollars and cents strings."""
    dollars = int(price)
    cents = int((price - dollars) * 100)
    return str(dollars), f"{cents:02d}"


def format_quantity(qty: int) -> str:
    """Format quantity as 5-digit zero-padded string."""
    return f"{qty:05d}"


def build_consolidated_data(data: dict) -> str:
    """Build Block 26 consolidated data string."""
    parts = []
    if data.get("routing_identifier"):
        parts.append(f"RIC: {data['routing_identifier']}")
    if data.get("unit_of_issue"):
        parts.append(f"UI: {data['unit_of_issue']}")
    if data.get("quantity"):
        parts.append(f"QTY: {format_quantity(int(data['quantity']))}")
    if data.get("condition_code"):
        parts.append(f"COND: {data['condition_code']}")
    if data.get("unit_price"):
        parts.append(f"UP: ${data['unit_price']}")
    return " | ".join(parts)


def build_additional_data(data: dict) -> str:
    """Build Block 27 additional data/POC string."""
    lines = []
    if data.get("requisitioner_name"):
        lines.append(f"POC: {data['requisitioner_name']}")
    if data.get("requisitioner_phone"):
        lines.append(f"Phone: {data['requisitioner_phone']}")
    if data.get("requisitioner_email"):
        lines.append(f"Email: {data['requisitioner_email']}")
    if data.get("special_handling"):
        lines.append(f"SPECIAL: {data['special_handling']}")
    return "\n".join(lines)


def fill_dd1348_form(data: Dict, template_path: str, output_path: str) -> None:
    """
    Fill DD Form 1348-1A with requisition data.

    Args:
        data: Dictionary containing requisition data with keys like:
              - nsn: National Stock Number (e.g., "8415-01-545-8556")
              - item_description: Item name/nomenclature
              - quantity: Number of units (int or string)
              - unit_of_issue: Unit code (e.g., "EA")
              - unit_price: Price per unit (float)
              - document_number: 14-char DTID
              - ship_from_dodaac: Origin DoDAAC
              - ship_to: Destination description
              - condition_code: Item condition (e.g., "A")
              - requisitioner_name, requisitioner_phone: POC info

        template_path: Path to blank DD 1348-1A PDF
        output_path: Path for filled output PDF
    """
    reader = PdfReader(template_path)
    writer = PdfWriter()
    writer.append(reader)

    # Build field values from input data
    field_values = {}

    # Total Price (Block 1)
    if data.get("extended_price"):
        dollars, cents = format_price(float(data["extended_price"]))
        field_values[FIELD_MAPPING["total_price_dollars"]] = dollars
        field_values[FIELD_MAPPING["total_price_cents"]] = cents
    elif data.get("quantity") and data.get("unit_price"):
        ext_price = int(data["quantity"]) * float(data["unit_price"])
        dollars, cents = format_price(ext_price)
        field_values[FIELD_MAPPING["total_price_dollars"]] = dollars
        field_values[FIELD_MAPPING["total_price_cents"]] = cents

    # Ship From (Block 2)
    if data.get("ship_from_dodaac"):
        ship_from = data["ship_from_dodaac"]
        if data.get("ship_from_location"):
            ship_from += f" {data['ship_from_location']}"
        field_values[FIELD_MAPPING["ship_from"]] = ship_from

    # Ship To (Block 3)
    if data.get("ship_to"):
        field_values[FIELD_MAPPING["ship_to"]] = data["ship_to"]

    # Mark For (Block 4)
    if data.get("mark_for"):
        field_values[FIELD_MAPPING["mark_for"]] = data["mark_for"]

    # Document Number (Block 24)
    if data.get("document_number"):
        field_values[FIELD_MAPPING["document_number"]] = data["document_number"]

    # NSN (Block 25)
    if data.get("nsn"):
        field_values[FIELD_MAPPING["nsn"]] = data["nsn"]

    # Consolidated Data (Block 26)
    field_values[FIELD_MAPPING["consolidated_data"]] = build_consolidated_data(data)

    # Item Nomenclature (Block 17)
    if data.get("item_description"):
        field_values[FIELD_MAPPING["item_nomenclature"]] = data["item_description"]

    # Additional Data / POC (Block 27)
    field_values[FIELD_MAPPING["additional_data"]] = build_additional_data(data)

    # Unit of Issue
    if data.get("unit_of_issue"):
        field_values[FIELD_MAPPING["unit_of_issue"]] = data["unit_of_issue"]

    # Quantity
    if data.get("quantity"):
        field_values[FIELD_MAPPING["quantity"]] = format_quantity(int(data["quantity"]))

    # Unit Price
    if data.get("unit_price"):
        dollars, cents = format_price(float(data["unit_price"]))
        field_values[FIELD_MAPPING["unit_price_dollars"]] = dollars
        field_values[FIELD_MAPPING["unit_price_cents"]] = cents

    # Condition Code
    if data.get("condition_code"):
        field_values[FIELD_MAPPING["condition_code"]] = data["condition_code"]

    # Total Weight (Block 20)
    if data.get("weight_lbs") or data.get("total_weight"):
        field_values[FIELD_MAPPING["total_weight"]] = str(data.get("weight_lbs") or data.get("total_weight"))

    # Total Cube (Block 21)
    if data.get("cube_ft") or data.get("total_cube"):
        field_values[FIELD_MAPPING["total_cube"]] = str(data.get("cube_ft") or data.get("total_cube"))

    # Doc Date (Block 5)
    if data.get("date_prepared"):
        field_values[FIELD_MAPPING["doc_date"]] = data["date_prepared"]
    else:
        field_values[FIELD_MAPPING["doc_date"]] = datetime.now().strftime("%Y-%m-%d")

    # Filter out empty values and apply to PDF
    field_values = {k: v for k, v in field_values.items() if v}

    # Update form fields
    try:
        writer.update_page_form_field_values(writer.pages[0], field_values)
    except Exception as e:
        print(f"Warning: Could not update some fields via standard method: {e}")
        print("Attempting alternative field update...")
        # Alternative: update via annotations
        page = writer.pages[0]
        if "/Annots" in page:
            for annot in page["/Annots"]:
                annot_obj = annot.get_object()
                if "/T" in annot_obj:
                    field_name = annot_obj["/T"]
                    if field_name in field_values:
                        annot_obj.update({"/V": field_values[field_name]})

    # Write output
    with open(output_path, "wb") as f:
        writer.write(f)

    print(f"Successfully filled DD Form 1348-1A: {output_path}")
    print(f"Fields populated: {len(field_values)}")


def main():
    """Command-line interface."""
    if len(sys.argv) < 4:
        print("Usage: python fill_dd1348.py <input_data.json> <template.pdf> <output.pdf>")
        print("\nExample:")
        print("  python fill_dd1348.py requisition.json dd13481a.pdf filled_form.pdf")
        sys.exit(1)

    input_json = sys.argv[1]
    template_pdf = sys.argv[2]
    output_pdf = sys.argv[3]

    # Load input data
    with open(input_json, 'r') as f:
        data = json.load(f)

    # Fill the form
    fill_dd1348_form(data, template_pdf, output_pdf)


if __name__ == "__main__":
    main()
